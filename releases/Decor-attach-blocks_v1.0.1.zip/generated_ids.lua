-- This is a generated file
-- Do not modify it, unless you know exactly what you are doing

ModId = "bf9b3f8f-d984-4f99-9111-e73e5f6ab063"

IdMap = {
	{ "BLOCK", "BUILDING", "e5f5e53d-377c-4d8d-9c24-5c645327c301" },
	{ "BLOCK_PART", "BUILDING_PART", "367b5a03-41dc-4129-81e3-211533d8773f" },
	{ "icons/Icon_Button_Swatch_1.png", "", "6a9fa897-b8fd-474e-99f0-f6334a1e096d" },
	{ "BLOCK_TILING_PART", "BUILDING_PART", "10b52bec-dcf3-4c66-a50f-75fffee0baf2" },
	{ "models/Cube Base Color.png", "", "53aa5b16-60ef-4e80-8be5-abffdbc955b0" },
	{ "BLOCK_TOP_PART", "BUILDING_PART", "2f6560de-550d-4cde-858b-f8babb852802" },
	{ "EVENT_BLOCK_UNLOCK", "EVENT", "471be370-f826-40fa-afb5-ea2a4dbb59ef" },
	{ "models/Scalable_Attach_Cube.fbx", "", "d1ab4331-1f06-45ec-b651-60b3fd87998f" },
	{ "models/Tex_Wall_Stone_Rustic_01A_Diff.png", "", "6812947e-0e24-4c7f-a22c-84d302455c31" },
	{ "models/Block Base Color.png", "", "a498b521-4832-4850-8cdc-9dae8af27af8" },
	{ "BLOCK_MATERIAL_SET_LIST", "MATERIAL_SET_LIST", "4669c62f-f1f3-451a-9889-8e8cd90a0ed6" },
	{ "icons/Icon_Button_Swatch_2.png", "", "a819f8e5-ccd7-46d2-8abb-481bb2a59409" },
	{ "icons/Icon_Button_Swatch_3.png", "", "a643be8a-f882-423f-8b00-daba45bd9ac6" },
	{ "icons/Icon_Button_Swatch_4.png", "", "291a70d0-194d-46c1-93f7-7546457b8f44" },
	{ "icons/Icon_Button_Swatch_5.png", "", "61dbc784-0f24-4042-a43c-0652addf879a" },
	{ "icons/Icon_Button_Swatch_6.png", "", "0da79e56-d4b0-4c31-9f9f-7eb97b06d247" },
	{ "icons/Icon_Button_Swatch_7.png", "", "64937b96-557b-4788-ac10-7ad18afafd66" },
	{ "icons/Icon_Button_Swatch_8.png", "", "c4ddf65c-aba8-4a5c-a166-4cf3ec283ba2" },
}
